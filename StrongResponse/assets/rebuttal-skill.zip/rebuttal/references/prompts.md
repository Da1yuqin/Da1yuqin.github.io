# Rebuttal · 提示词

```text
读取 rebuttal/SKILL.md。论文：【】；完整 reviews：【】；审稿人画像：【】；真实证据与位置：【】；当轮规则、字数和允许修改的文件：【】。先不限字数，按合作模板逐题写清拟回答、思路、依据、缺口与合作确认事项。汇总去重后的实验编号、对应 Q、目的、对照、判断依据和分工，分别报告必做新增、已完成、剩余、可选、待确认项及单列的重跑和重分析；运行次数另列。确认后起草完整或限字回复，首句先回答，再给必要依据、解释与位置，填入后按实际口径计数。模拟降分按理由修改，维持时处理未解决关切，再交同一角色复核；模拟提分后交作者人工核对事实与幻觉。AC letter 另用独立 skill。 完整回复可按原审稿章节使用 W1／Q1 等编号。回应 novelty／贡献质疑时，先准确肯定审稿人说对的具体点，学习“You correctly identify [specific mechanism] as [its supported role].”的文风。接着用一句话说核心贡献，再用表格给证据。用具体理解提供情绪价值，省去泛泛感谢和恭维。提供最小完整示例帮助理解；可改正文时标色并在回复中说明位置，以解决审稿问题与 typo 为主。
表达要求：用最简洁、最直白的话回答对方的具体问题，先给答案，再给必要证据和位置。不用空话、套话，不重复背景和结论，不作无关扩展。不添加任何防御性陈述。
实验数据优先用表格呈现，列出对照、关键条件、数值、单位及必要统计信息；表后只写必要结论，不再用长句重复报数。
不限字数的 rebuttal 中，正文和补充材料里能直接回答该题的原文、定义、设置和结果，必须全部摘进该题的证据表，并标明节号、表号或行号。按实际相关内容增行，不固定证据条数或来源类型。
通用模板和完整示例使用明显的 mock 名称、结果和出处，如 Method A、Metric A、Metric B；不用具体研究内容和数值。Novelty 文风示范可保留作者明确提供的原句与数据。
需要提醒审稿人回复时：先提醒查看并回复 rebuttal，说明愿意继续解答；以 if we have addressed all your concerns 为前提，再写 we would be grateful if you would consider raising your score。尚未回复时请求反馈，收到回复后才感谢 response。
```

---

Da1yuqin / [StrongResponse](https://da1yuqin.github.io/StrongResponse/)，[CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)。转载请保留署名、出处及许可，改写注明改动。
