---
name: rebuttal-reviewer-profile
description: Infer evidence-grounded reviewer profiles and preferences from complete reviews, then simulate each reviewer's response to a rebuttal and run a targeted revision loop.
---

# 审稿人画像与模拟

独立分析审稿人，再按同一画像模拟审核回复。完整画像、刻板印象、投入表和 Revise loop 见 [rules.md](references/rules.md)，复制提示词见 [prompts.md](references/prompts.md)。

## 分析画像

读取论文、完整 review、评分和 Confidence、真实讨论。逐句提取 Weaknesses、Questions、Strengths、Summary、附录与评分理由里的信号，保留原话及位置。

1. 从 Weaknesses 和审稿文本逆推真正的核心关切，列出要求最高的问题。
2. 记录最欣赏的点、阅读深度与理解偏差、期待的 evidence、参与和改评信号、负面风险。
3. 逐项判断偏好：情绪价值和尊重、实验量和覆盖、背景知识与解释、技术细节和扫读习惯。低 Confidence 结合基础概念问题，可能意味着需要背景解释；也可能是论文没有讲清楚。
4. 每项附原话依据与不确定性。高分、客气不代表要求低；笑面虎优先级极高。每位审稿人都要完整回复，再按高、极大、中和极高分配额外投入。
5. 输出画像、原问题清单和模拟设置，作为 Rebuttal 起草与复核的输入；分类只供作者内部使用。

## 按画像模拟审核

写完回复后，逐位提供审稿人的完整原话、原评分、Confidence 和后续讨论，先载入画像再进入审稿人角色。按画像设严格程度，拟合核心关切和要求最高的问题；实验导向查数据，情绪价值导向查是否被理解，背景解释导向查术语和中间推理。不要默认所有人都是同一种专家。

按原问题清单逐题带着疑问读 Rebuttal，定位答案与证据，检查实验分析、解释深度、语气、长度与扫读效果。输出：Q、原问题、画像关注点、回复位置、通过/不通过、具体原因、最小改法、缺失证据。

## Revise loop

逐题反馈后，给出整体模拟判断：提分 / 维持 / 降分 / 无法判断，说明对应的原话与回复依据。只在原评分和当轮量表已给定时提供模拟分数，不补造评分。

模拟提分时记录理由，结束这位审稿人的循环；模拟降分时必须给出具体降分理由、对应 Q 和最小改法，交 Rebuttal skill 按理由修改。维持时指出未解决的关切并针对性修改。维持且原问题均已明确回答、没有剩余可执行修改，或原分已达到量表上限时，记录理由并交作者人工确认；不为追求模拟提分反复改写。修改后用同一份原话、同一画像和同一评分口径复核；新 review 信息出现时才更新画像，不为提分降低标准。无法判断时说明缺什么材料，交作者确认。

该环节可自动运行，最后由作者人工核对每题是否答全、事实、数值、引用、实验状态和修改位置，确认没有幻觉。人工发现问题时修正并复核受影响的回复。模拟反馈与模拟改分仅供内部使用，不冒充真实认可或改分，不写入正式回复或 AC letter。需要实验或事实补充时交作者决定；不自动提交、改稿或运行实验。此 skill 不写 AC letter。

---

Da1yuqin / [StrongResponse](https://da1yuqin.github.io/StrongResponse/)，[CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)。转载请保留署名、出处及许可，改写注明改动。
